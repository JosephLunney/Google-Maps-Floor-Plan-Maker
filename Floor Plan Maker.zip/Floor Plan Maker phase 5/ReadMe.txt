To get started, click on the index.html file!

On the web app, click on the "Click here for more info" tab on the upper right to learn how to use this. 